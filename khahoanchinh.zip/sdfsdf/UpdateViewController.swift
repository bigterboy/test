//
//  UpdateViewController.swift
//  sdfsdf
//
//  Created by Truong Phan Qui on 4/2/17.
//  Copyright © 2017 Truong Phan Qui. All rights reserved.
//

import UIKit
import CoreData

class UpdateViewController: UIViewController {

    
    var firstNameArr:[String] = []
    var lastNameArr:[String] = []
    
    var dayOfBirthArr:[String] = []
    var classNameArr:[String] = []
    var classIDrr:[String] = []
    var noteArr:[String] = []
    
    
    
    var hocsinh = [NSManagedObject]()
    
    var temp:Int?
    
    
    
    @IBOutlet weak var txtFirstName: UITextField!
    
    
    
    @IBOutlet weak var txtLastName: UITextField!
    
    
    @IBOutlet weak var txtDayOfBirth: UITextField!
    
    
    @IBOutlet weak var txtClassName: UITextField!
    
    
    
    
    @IBOutlet weak var txtClassID: UITextField!
    
    
    
    @IBOutlet weak var txtNote: UITextField!
    
    
    
    @IBOutlet weak var labelTest: UILabel!
    
    
    
    @IBAction func btnUpdate(_ sender: Any) {
        
        
        
        
        
        
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        
        
        
        
        
        let managedContext = appDelegate.persistentContainer.viewContext
        
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "HOCSINH")
        
        fetchRequest.returnsObjectsAsFaults = false
        
        
        
        
        
        
        
        do
        {
            let results = try managedContext.fetch(fetchRequest)
            for managedObject in results
            {
                if(temp! > 1)
                {
                    temp = temp! - 1
                }
                else
                {
                    let managedObjectData:NSManagedObject = managedObject as! NSManagedObject
                
                    managedObjectData.setValue(txtFirstName.text, forKey: "firtName")
                    managedObjectData.setValue(txtLastName.text, forKey: "lastName")
                
                    managedObjectData.setValue(txtDayOfBirth.text, forKey: "dayOfBirth")
                    managedObjectData.setValue(txtClassName.text, forKey: "className123")
                    managedObjectData.setValue(txtClassID.text, forKey: "classID")
                    managedObjectData.setValue(txtNote.text, forKey: "note")
                    
                    
                //managedContext.delete(managedObjectData)
                
                
                //managedContext.setValue("OK", forKey: "firtName")
                //managedContext.setValue("OK", forKey: "lastName")
                
                
             
                
                    do
                    {
                        try managedContext.save()
                        print("Da xoa xong")
                    }
                    catch
                    {
                        print("co loi")
                    }
                
                
                
                    lastNameArr.remove(at: lastNameArr.count-1)
                    firstNameArr.remove(at: firstNameArr.count-1)
                    
                    
                    break;
                
                }
                //self.tableView.reloadData()
                
                
                //break;
                
            }
        } catch let error as NSError {
            print("Detele all data in \("KhachHang") error : \(error) \(error.userInfo)")
        }
        
        //tableView.beginUpdates()
        

        
        
        
        
        
        
    }
    
    
    
    
    
    

    
    
    
    
    
    var number:Int?
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        temp = number
        
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let contex = appDelegate.persistentContainer.viewContext
        
        
        
        let reques = NSFetchRequest<NSFetchRequestResult>(entityName: "HOCSINH")
        //reques.returnsObjectsAsFaults = false
        
        
        
        
        
        
        
        
        
        
        
        // bo cai duoi
        do {
            
            let results = try contex.fetch(reques)
            
            if results.count > 0
            {
                for results in results as! [NSManagedObject]
                {
                    
                    if let lastname = results.value(forKey: "lastName") as? String
                    {
                        lastNameArr.append(lastname)
                        //print(password)
                    }
                    
                    if let firstName = results.value(forKey: "firtName") as? String
                    {
                        firstNameArr.append(firstName)
                        //print(password)
                    }
                    
                    
                    
                    if let dayOfBirth = results.value(forKey: "dayOfBirth") as? String
                    {
                        dayOfBirthArr.append(dayOfBirth)
                        //print(password)
                    }

                    if let className123 = results.value(forKey: "className123") as? String
                    {
                        classNameArr.append(className123)
                        //print(password)
                    }

                    if let classID = results.value(forKey: "classID") as? String
                    {
                        classIDrr.append(classID)
                        //print(password)
                    }

                    if let note = results.value(forKey: "note") as? String
                    {
                        noteArr.append(note)
                        //print(password)
                    }

                    
                }
                
                //print(idArr)
                //print(passwordArr)
            }
            
        }
        catch
        {
            
        }
        

        
        txtFirstName.text = firstNameArr[number!-1]
        txtLastName.text = lastNameArr[number!-1]
        txtDayOfBirth.text = dayOfBirthArr[number!-1]
        txtClassName.text = classNameArr[number!-1]
        txtClassID.text = classIDrr[number!-1]
        txtNote.text = noteArr[number!-1]
        
        
        
        
        
        
        
        
        
        

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        
        //if let movie = movie{
        //titileLabel.text  = movie.name + " " +  movie.derector + " " + movie.derector
        //yearLabel.text = "\(movie.year)"
        //directorLabel.text = movie.derector
        
        //if let titleText=titleText
        //{
        //titlelabel.text = titleText
        //}
        
        
        if let number = number
        {
            labelTest.text = "\(number)"
        }
        
        
    }

    
    
    
    
    
    
    
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

//
//  DSHSTableViewController.swift
//  sdfsdf
//
//  Created by Truong Phan Qui on 4/2/17.
//  Copyright © 2017 Truong Phan Qui. All rights reserved.
//

import UIKit
import CoreData

class DSHSTableViewController: UITableViewController  {

    var firstNameArr:[String] = []
    var lastNameArr:[String] = []
    
    
    
    
    
    
    @IBAction func btnDelete(_ sender: Any) {
        
        
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        
        let managedContext = appDelegate.persistentContainer.viewContext
        
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "HOCSINH")
        
        fetchRequest.returnsObjectsAsFaults = false
        
        
        
        
        
        
        
        do
        {
            let results = try managedContext.fetch(fetchRequest)
            for managedObject in results
            {
                let managedObjectData:NSManagedObject = managedObject as! NSManagedObject
                managedContext.delete(managedObjectData)
                
                
                
                do
                {
                    try managedContext.save()
                    print("Da xoa xong")
                }
                catch
                {
                    print("co loi")
                }
                
                
                
                lastNameArr.remove(at: lastNameArr.count-1)
                firstNameArr.remove(at: firstNameArr.count-1)
                
                
                self.tableView.reloadData()
                
                
                break;
                
            }
        } catch let error as NSError {
            print("Detele all data in \("KhachHang") error : \(error) \(error.userInfo)")
        }

        //tableView.beginUpdates()
        
        
        
        
        
        
      

    
        
        
        
      
        
        
        
        
        
    }
    
    
    
    
    
    
    @IBAction func btnSAVE2(_ sender: Any) {
        
        
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let contex = appDelegate.persistentContainer.viewContext
        
        let newUser = NSEntityDescription.insertNewObject(forEntityName: "HOCSINH", into: contex)
        
        
        
        
        
        
        
        
        
        
        newUser.setValue("truong phan", forKey: "lastName")  // lưu xuống core data
        newUser.setValue("qui", forKey: "firtName")
        
        
        lastNameArr.append("truong phan")
        firstNameArr.append("qui")
        
        
        
        
        do {
            try contex.save()
            print("Da luu !")
        }
        catch {
            
        }
        
        self.tableView.reloadData()
        
        
        
        
        //self.tableView.reloadRows(at: IndexPath, with: .automatic)
        //self.tableView.reloadRows(at: IndexPath, with: .automatic)
        
    
        //viewDidLoad()
        
        
        
        
        
        //lastNameArr.append(lastname)
        
        
        
        
        
        
        
        
        /*
        
        let appDelegate1 = UIApplication.shared.delegate as! AppDelegate
        let contex1 = appDelegate.persistentContainer.viewContext
        
        
        
        let reques1 = NSFetchRequest<NSFetchRequestResult>(entityName: "HOCSINH")
        reques1.returnsObjectsAsFaults = false

        */
        
        
        
        
        
        
        
    }
    
    
    
    
    
   

 
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        //firstNameArr = [""]
        //lastNameArr = [""]

        //firstNameArr = nil
        //lastNameArr = [""]
        
        
         self.navigationItem.rightBarButtonItem = self.editButtonItem
        
        
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let contex = appDelegate.persistentContainer.viewContext
        
        
        
        let reques = NSFetchRequest<NSFetchRequestResult>(entityName: "HOCSINH")
        reques.returnsObjectsAsFaults = false
        
        
        
        do {
            
            let results = try contex.fetch(reques)
            
            if results.count > 0
            {
                for results in results as! [NSManagedObject]
                {
                    
                    if let lastname = results.value(forKey: "lastName") as? String
                    {
                        lastNameArr.append(lastname)
                        //print(password)
                    }
                    
                    if let firstName = results.value(forKey: "firtName") as? String
                    {
                        firstNameArr.append(firstName)
                        //print(password)
                    }
                    
                }
                
                //print(idArr)
                //print(passwordArr)
            }
            
        }
        catch
        {
            
        }
        

        
        self.tableView.reloadData()
        
        
        
        /*
        func viewWillAppear(animated: Bool)
        {
            
            tableView.reloadData()
            
            return false
        }
        */
        
        
        
        
        
        
        
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return lastNameArr.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)

        // Configure the cell...

        
        cell.textLabel?.text = lastNameArr[indexPath.row] + " " + firstNameArr[indexPath.row]

        
        return cell
    }

    
    func getContext () -> NSManagedObjectContext {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        return appDelegate.persistentContainer.viewContext
    }
    
    
    
    
    
    
    
    func controllerWillChangeContent(controller: NSFetchedResultsController<NSFetchRequestResult>) {
        self.tableView.beginUpdates()
    }
    

    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "toDetailsSegue"
        {
            if let indexPath = self.tableView.indexPathForSelectedRow
            //if let indexpath = tableView.indexPathForSelectedRow
            {
                let destVC  = segue.destination as! UpdateViewController
                //destVC.movie = array[indexPath.row]
                
                //let destVC = segue.destination as! DetailsViewController // gửi dữ liệu sang ->> ....
                
                //destVC.titleText = array[indexPath.row]  // truyen du lieu qua
                
                
                
                destVC.number = indexPath.row + 1
                
                
            }
        }
    }
    

    
    
    
    
    /*
    
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            
            
            
            //tableView.deleteRows(at: [indexPath], with: .automatic)
            
            
            
           
            tableView.beginUpdates()
            
            self.firstNameArr.remove(at: indexPath.row)
            self.lastNameArr.remove(at: indexPath.row)
            
            
            tableView.deleteRows(at: [indexPath], with: .automatic)
            
            
            
            
            tableView.endUpdates()

            
            
            
            
            let appDelegate = UIApplication.shared.delegate as! AppDelegate
            
            let managedContext = appDelegate.persistentContainer.viewContext
            
            let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "HOCSINH")
            
            fetchRequest.returnsObjectsAsFaults = false
            
            
            
            
            var temp123 = indexPath.row
            
            
            
            do
            {
                
                
                
                let results = try managedContext.fetch(fetchRequest)
                for managedObject in results
                {
                    if temp123   > 0
                    {
                        temp123 = temp123 - 1
                    }
                    else
                    {
                    
                        let managedObjectData:NSManagedObject = managedObject as! NSManagedObject
                        managedContext.delete(managedObjectData)
                    
                    
                    
                        do
                        {
                            try managedContext.save()
                            print("Da xoa xong")
                        }
                        catch
                        {
                            print("co loi")
                        }
                    
                    
                    
                        //lastNameArr.remove(at: lastNameArr.count-1)
                        //firstNameArr.remove(at: firstNameArr.count-1)
                        
                    
                        self.tableView.reloadData()
                    
                        
                        break;
                        
                        
                    }
                    
                }
            } catch let error as NSError {
                print("Detele all data in \("KhachHang") error : \(error) \(error.userInfo)")
            }

            
            
            
            
            
            
            
            
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    

    
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    

    
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

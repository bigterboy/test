//
//  ViewController.swift
//  sdfsdf
//
//  Created by Truong Phan Qui on 4/2/17.
//  Copyright © 2017 Truong Phan Qui. All rights reserved.
//

import UIKit
import CoreData
class ViewController: UIViewController {

    
    
    @IBOutlet weak var txtFirstName: UITextField!
    
    
    @IBOutlet weak var txtLastName: UITextField!
    
    
    
    @IBOutlet weak var txtDayOfBirth: UITextField!
    
    
    @IBOutlet weak var txtClassID: UITextField!
    
    
    
    @IBOutlet weak var txtClassName: UITextField!
    
    
    @IBOutlet weak var txtNote: UITextField!
    
    
    
    
    
    @IBAction func btnLuu(_ sender: Any) {
        
        
        
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let contex = appDelegate.persistentContainer.viewContext
        
        let newUser = NSEntityDescription.insertNewObject(forEntityName: "HOCSINH", into: contex)
        
        
        
        
        newUser.setValue(txtLastName.text, forKey: "lastName")
        newUser.setValue(txtFirstName.text, forKey: "firtName")
        newUser.setValue(txtDayOfBirth.text, forKey: "dayOfBirth")
        newUser.setValue(txtClassName.text, forKey: "className123")
        newUser.setValue(txtClassID.text, forKey: "classID")
        newUser.setValue(txtNote.text, forKey: "note")
        
        
        
        
        do {
            try contex.save()
            print("Da luu !")
        }
        catch {
            
        }
        
        
        //tableView.reloadData()
        
        //self.tableView.endUpdates()

        
        
        
        
        
        
    }
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    
    
    
    
    


}

